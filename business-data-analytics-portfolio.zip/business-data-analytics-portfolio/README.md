# Business Data Analytics Portfolio

An end-to-end retail sales analytics project demonstrating data validation, KPI calculation, SQL reporting, and reproducible Python analysis.

## Business questions
- How are monthly sales and profit trending?
- Which product categories drive revenue?
- What is the average order value?
- Which transactions have data-quality issues?

## Stack
Python 3.10+, pandas, SQLite (standard library), SQL, pytest.

## Project layout
```
data/raw/           Synthetic example transactions
src/                Reusable analytics code
sql/                SQLite-compatible business queries
notebooks/          Notebook workspace
reports/            Generated analysis outputs
 tests/             Automated tests
```

## Quick start
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python -m src.analyze
python -m pytest
```

The analysis writes `reports/kpi_summary.csv` and `reports/category_summary.csv`.

## Data and assumptions
The sample dataset is **synthetic** and contains no customer personal information. `revenue = quantity * unit_price`; `profit = revenue - quantity * unit_cost`. An order may have multiple line items, so average order value divides total revenue by distinct order IDs.

## Next steps
Add more synthetic records, visualizations in Power BI, and automated CI checks.

## License
MIT.
